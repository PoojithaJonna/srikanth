package com.application.TodoApp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.application.TodoApp.entity.Todo;
import com.application.TodoApp.service.TodoService;

import jakarta.validation.Valid;


@RestController
public class TodoController {
	
	@Autowired
	TodoService todoService;
	
	@GetMapping("/")
	public ResponseEntity<String> status(){
		return new ResponseEntity<String>("UP",HttpStatus.OK);
	}
	
	@GetMapping("/todos")
	public ResponseEntity<List<Todo>> getAllTodos(){
		List<Todo> todos= todoService.getAllTodos();
		return new ResponseEntity<List<Todo>>(todos,HttpStatus.OK);
	}
	
	@PostMapping("/todos")
	public ResponseEntity<Todo> newTodo(@Valid @RequestBody Todo todo){
		Todo res = todoService.saveTodo(todo);
		return new ResponseEntity<Todo>(res,HttpStatus.CREATED);
	}
	
	@GetMapping("/todos/{id}")
	public ResponseEntity<Todo> fetchById(@PathVariable int id){
		Todo todo = todoService.getTodoById(id);
		if(todo==null) return new ResponseEntity<Todo>(HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Todo>(todo,HttpStatus.OK);
		
	}
	
	@PutMapping("/todos/{id}")
	public ResponseEntity<Todo> updateById(@RequestBody Todo todo,@PathVariable int id){
		Todo res = todoService.updateTodoById(todo,id);
		if(res==null) return new ResponseEntity<Todo>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Todo>(res,HttpStatus.CREATED);
	}
	
	@PatchMapping("/todos/{id}")
	public ResponseEntity<Todo> markAsCompleted(@RequestParam Boolean completed,@PathVariable int id){
		Todo res = todoService.updateCompleted(completed,id);
		return new ResponseEntity<Todo>(res,HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping("/todos/{id}")
	public ResponseEntity<Todo> deleteTodo(@PathVariable int id){
		todoService.deletedById(id);
		return new ResponseEntity<Todo>(HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/todos/count")
	public ResponseEntity<Integer> todosCount(){
		Integer count = todoService.getCount();
		return new ResponseEntity<Integer>(count,HttpStatus.OK);
	}
}
