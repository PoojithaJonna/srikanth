package com.application.TodoApp.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.TodoApp.Repo.TodoRepo;
import com.application.TodoApp.entity.Todo;


@Service
public class TodoServiceImpl implements TodoService{
	
	@Autowired
	private  TodoRepo todoRepo;

	@Override
	public Todo saveTodo(Todo todo) {
		todo.setCreatedAt(new Date());
		todoRepo.save(todo);
		return todo;
	}

	@Override
	public List<Todo> getAllTodos() {
		List<Todo>  todos = todoRepo.findAll();
		return todos;
	}

	@SuppressWarnings("deprecation")
	@Override
	public Todo getTodoById(int id) {
		// TODO Auto-generated method stub
		Todo todo = todoRepo.findById(id).orElse(null);
		return todo;
	}

	@Override
	public Todo updateTodoById(Todo todo,int id) {
		// TODO Auto-generated method stub
		Todo updateTodo = todoRepo.findById(id).orElse(null);
		if(updateTodo!=null) {
//		if(todo.getCompleted()!=null) updateTodo.setCompleted(todo.getCompleted());
		if(todo.getDescription()!=null) updateTodo.setDescription(todo.getDescription());
		if(todo.getTitle()!=null) updateTodo.setTitle(todo.getTitle());
		return todoRepo.save(updateTodo);
		}
		return null;
	}

	@Override
	public Todo updateCompleted(Boolean completed, int id) {
		Todo updateTodo = todoRepo.findById(id).orElse(null);
		if(updateTodo!=null) {
			updateTodo.setCompleted(completed);
			return todoRepo.save(updateTodo);
		}
		return updateTodo;
	}

	@Override
	public void deletedById(int id) {
		// TODO Auto-generated method stub
		todoRepo.deleteById(id);
	
	
	}

	@Override
	public Integer getCount() {
		Integer count = (int) todoRepo.count();
		return count;
	}

	

}
